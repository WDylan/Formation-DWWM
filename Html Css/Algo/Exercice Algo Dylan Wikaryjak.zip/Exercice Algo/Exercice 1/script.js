let N = 0,
    result = 0,
    i = 0;

while (N <= 21) {
    N = i;
    i++;
    result += N;
    console.log(`N vaut ${N} le resultat attendu est ${result}`)
}

// let O = 0,
//     resultat = 0,
//     l = 0;

// do {
//     O = l;
//     l++;
//     resultat += O;
//     console.log(`O vaut ${O} le resultat attendu est ${resultat}`)
// } while (O <= 21)